# avTools for TouchDesigner — distribution 49

Start with [Plugins/README.md](Plugins/README.md) for the GUI setup walkthrough.
