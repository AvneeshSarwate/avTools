# avTools for TouchDesigner — distribution 30

Start with [Plugins/README.md](Plugins/README.md) for the GUI setup walkthrough.
