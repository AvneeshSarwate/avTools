# avTools for TouchDesigner — distribution 34

Start with [Plugins/README.md](Plugins/README.md) for the GUI setup walkthrough.
