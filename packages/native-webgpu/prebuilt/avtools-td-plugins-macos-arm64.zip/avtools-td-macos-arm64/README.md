# avTools for TouchDesigner — distribution 20

Start with [Plugins/README.md](Plugins/README.md) for the GUI setup walkthrough.
